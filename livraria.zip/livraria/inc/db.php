<?php
$host = '127.0.0.1';
$db   = 'livraria';
$user = 'root';
$pass = '';
$opts = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
];
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, $opts);
} catch (Exception $e) {
    die('Erro DB: ' . $e->getMessage());
}
?>